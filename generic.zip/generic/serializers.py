from rest_framework import serializers
from .models import SitePolicy

class SitePolicySerializer(serializers.ModelSerializer):
    class Meta:
        model = SitePolicy
        fields = ['title', 'content']
