from django.urls import path
from .views import PrivacyPolicyView, PrivacyPolicyRetrieveView

urlpatterns = [
    path('admin/privacy-policy/', PrivacyPolicyView.as_view(), name='privacy-policy-update'),
    path('privacy-policy/', PrivacyPolicyRetrieveView.as_view(), name='privacy-policy-get'),
]
