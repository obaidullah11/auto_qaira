from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAdminUser, AllowAny
from rest_framework import status
from .models import SitePolicy
from .serializers import SitePolicySerializer
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi

class PrivacyPolicyView(APIView):
    permission_classes = [IsAdminUser]

    @swagger_auto_schema(
        request_body=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            required=['content'],
            properties={
                'content': openapi.Schema(type=openapi.TYPE_STRING, description='Privacy policy content'),
            },
        ),
        responses={200: openapi.Response(description="Success")},
        tags=['Privacy Policy']
    )
    def post(self, request):
        content = request.data.get('content')
        policy, created = SitePolicy.objects.update_or_create(
            title="Privacy Policy",
            defaults={'content': content}
        )
        return Response({
            'success': True,
            'message': 'Privacy policy updated',
            'data': SitePolicySerializer(policy).data
        })


class PrivacyPolicyRetrieveView(APIView):
    permission_classes = [AllowAny]

    @swagger_auto_schema(
        responses={200: openapi.Response(description="Success")},
        tags=['Privacy Policy Retrieval']
    )
    def get(self, request):
        try:
            policy = SitePolicy.objects.get(title="Privacy Policy")
            return Response({
                'success': True,
                'message': 'Privacy policy retrieved successfully',
                'data': SitePolicySerializer(policy).data
            })
        except SitePolicy.DoesNotExist:
            return Response({
                'success': False,
                'message': 'Privacy policy not found',
                'data': None
            }, status=status.HTTP_404_NOT_FOUND)
